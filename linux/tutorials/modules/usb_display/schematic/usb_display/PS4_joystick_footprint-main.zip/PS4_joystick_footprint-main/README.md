# PS4_joystick_footprint
PS4 Joystick Footprint for Kicad

This footprint has been tested using a breakout PCB, whch is also available here
